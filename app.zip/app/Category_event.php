<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category_event extends Model
{
    protected $fillable = ['name_category'];
}
