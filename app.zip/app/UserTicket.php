<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserTicket extends Model
{
  //
}
