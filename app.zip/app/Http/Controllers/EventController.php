<?php

namespace App\Http\Controllers;


use App\Category_event;
use App\Category_ticket;
// use App\E_organizer;
use App\Event;
use App\Ticket;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class EventController extends Controller
{
  /**
   * Show the application dashboard.
   *
   * @return \Illuminate\Contracts\Support\Renderable
   */
  public function index()
  {
  	// $myevents = Event::leftJoin('category_events', 'events.ctgE_id', '=', 'category_events.id')
   //                          ->select('events.*', 'category_events.name_category AS Category_Event')
   //                          ->where('eo_id', $eo->id)
   //                          ->paginate(10);
  	$events = Event::rightJoin('tickets', 'tickets.event_id', '=', 'events.id')
                    // ->select('events.*', 'tickets.price as price')
                    ->selectRaw('events.*, MIN(tickets.price) AS price')
                    // ->min('tickets.price')
                    ->where('events.status', '!=', 'wait')
                    ->groupBy('events.id')
                    ->orderBy('events.id', 'desc')->get();
    // dd($events);
    return view('home', compact('events'));
  }

  public function show(Event $event)
  {
    $tickets = Ticket::leftJoin('category_tickets', 'tickets.ctgT_id', '=', 'category_tickets.id')
                      ->select('tickets.*', 'category_tickets.name_category AS Category_Ticket')
                      ->where('event_id', $event->id)
                      ->get();
    // $tickets = Ticket::all()->where('event_id', $event->id);
    // dd($tickets);

    return view('detailevent', compact('event', 'tickets'));
  }

  public function history()
  {
    return true;
  }

  public function ticket()
  {
    return view('detailticket');
  }

  // public function detailTicketEvent(Event $event)
  // {
  //   $tickets = Ticket::all()->where('event_id', $event->id);
  //   dd($tickets);
  // }
}
