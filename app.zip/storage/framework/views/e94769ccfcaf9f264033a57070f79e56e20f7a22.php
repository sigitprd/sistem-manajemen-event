

<?php $__env->startSection('title', 'Sign up'); ?>

<?php $__env->startSection('content'); ?>
                <section id="userpage">
                  <div class="userpage-container">
                    <div class="userform card-header">
                      <h2 class="h3 text-center m-0 font-weight-light text-white">Sign Up Event Organizer</h2>
                    </div>

                    <div class="form-group mb-0">
                                <a class="btn btn-link" href="<?php echo e(route('indexUser')); ?>">
                                    Submit success! Please wait to the response for admin.
                                </a>
                        </div>


                  </div>
                </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PSI-TUBES\e-vent\resources\views/auth/submit_response.blade.php ENDPATH**/ ?>