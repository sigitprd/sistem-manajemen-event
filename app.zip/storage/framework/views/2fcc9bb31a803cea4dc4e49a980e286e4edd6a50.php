<?php $__env->startSection('title', 'Transaction'); ?>



<?php $__env->startSection('content'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PSI-TUBES\e-vent\resources\views/mytransaction.blade.php ENDPATH**/ ?>