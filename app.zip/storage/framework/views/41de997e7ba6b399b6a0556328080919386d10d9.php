<!-- Edit Ticket Modal-->
  <div class="modal fade" id="editTicketModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Edit Ticket Test</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="" enctype="multipart/form-data" method="post" autocomplete="off" id="patchTicket">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row">
              <div class="col-md-4 from-group">
                <label for="event_id">Choice Your Events</label>
                <select class="form-control" id="e_event_id" name="event_id">
                    <?php $__currentLoopData = $myevents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myevent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($myevent->id); ?>"><?php echo e($myevent->event_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="col-md-4 from-group">
                <label for="ticket_name">Ticket Name</label>
                <input type="text" id="e_ticket_name" name="ticket_name" class="form-control" placeholder="Enter your Ticket name...">
              </div>
              <div class="col-md-4 from-group">
                <label for="ctgT_id">Category Ticket</label>
                <select class="form-control" id="e_ctgT_id" name="ctgT_id">
                    <?php $__currentLoopData = $category_tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctgticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ctgticket->id); ?>"><?php echo e($ctgticket->name_category); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-md-3 form-group">
                <label for="start_sale">Start Sale</label>
                <input type="date" id="e_start_sale" name="start_sale" class="form-control" id="exampleFormControlInput1" placeholder="Enter your Event name...">
              </div>
              <div class="col-md-3 form-group">
                <label for="end_sale">End Sale</label>
                <input type="date" id="e_end_sale" name="end_sale" class="form-control" placeholder="Enter your Event name...">
              </div>
              <div class="col-md-3 form-group">
                <label for="start_time">Start Time</label>
                <input type="time" id="e_start_time" name="start_time" class="form-control" placeholder="Enter your Event name...">
              </div>
              <div class="col-md-3 form-group">
                <label for="end_time">End Time</label>
                <input type="time" id="e_end_time" name="end_time" class="form-control" placeholder="Enter your Event name...">
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-md-6 form-group">
                <label for="price" class="">Price</label>
                <div class="wrapper" style="position:relative;">
                  <input class="form-control" type="text" id="e_price" name="price" style="padding-left: 38px;">
                  <span class="" style="left:6px;top:6px;position:absolute;">Rp.</span>
                </div>
              </div>
              <div class="col-md-6 form-group">
                <label for="quantity" class="">Quantity</label>
                <input class="form-control" id="e_quantity" type="text" name="quantity">
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-md-12 form-group">
                <label class="d-block" for="description">Description</label>
                <textarea id="e_description" name="description" class="form-control" placeholder="Write the description for ticket..."></textarea>
              </div>
            </div>
            <h6 for="ticket_photo" class="">Ticket Photo</h6>
            <div class="row">
              <div class="col-md-12 form-group picture-container">
                <img src="" class="picture-src" style="width: 28rem" id="edit_wizardPicturePreview" title="">
                <input type="file" id="edit_wizard-picture" class="d-inline-block" name="ticket_photo">
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <button class="btn btn-primary" type="submit" value="submit" >Submit</button>
          </div>
        </form>
      </div>
    </div>
  </div><?php /**PATH C:\xampp\htdocs\PSI-TUBES\e-vent\resources\views/modal/edit_ticket.blade.php ENDPATH**/ ?>